#!/bin/bash

/usr/bin/pip3 install -r requirements.txt
/usr/bin/pip3 install pyqt5
/usr/bin/pip3 install pyperclip
